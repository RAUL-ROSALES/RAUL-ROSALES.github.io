﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_2
{
   public class Operaciones
    {
        public double Suma(double a, double b)
        {
            double res;
            res = a + b;
            return res;
        }
        public double Resta(double a, double b)
        {
            double res = a-b;
            return res;
        }
        public double Multiplicacion(double a, double b)
        {
            double res= a*b;
            return res; 
        }
        public double Division(double a, double b)
        {
            double res = a/b;
            return res;
        }
    }
}
