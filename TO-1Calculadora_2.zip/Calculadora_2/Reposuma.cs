﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_2
{
   public class Reposuma
    {
        /*en esta clase de reposuma encapsulo mis variables para poder invocarlas desde cualquier otra clase*/
        private double valor1,valor2;
        public double Valor1
        {
            get { return valor1; }
            set { valor1 = value; }
        }
        public double Valor2
        {
            get { return valor2; }
            set { valor2 = value; }
        }
       
   }
}
