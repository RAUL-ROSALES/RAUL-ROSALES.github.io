﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*en el main nomas instacio la clase pricipal y de ahi la mando a llamar 
             para que ejecute todo lo que tiene*/
            Pricipal b = new Pricipal();
            b.Bienvenida();
            b.Obtener_datos();
            Console.ReadKey();
            /*posdata soy malo espresando como hize las cosas*/
        }
    }
}
