﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_2
{
   public class Pricipal
    {
        /*aqui cree una clase que llame pricipal
         y aqui cree 3 metodos
         que son la bienvenida uno para capturar los datos que ingrese el usuario para 
         realizar la operacion que el va a desear hacer*/
        Operaciones s = new Operaciones();//instacio la clase operacion para poder mandar a invocar los metodos 
        Reposuma mos = new Reposuma();//aqui instacio la clase repo para poder usar las variables que encapsule  
        public void Bienvenida()
        {
            Console.WriteLine("Bienvenido a Mi Programa");
        }
        public void Obtener_datos()
        {
            /*en este metodo pido al usuiaro que ingrese los datos en valiabres que ya tengo encapsuladas
             para poder usar las variabres encapsuladas instancio la clase*/
            Console.WriteLine("Ingrese Datos");
            Console.WriteLine("ingrese el primer numero");
            mos.Valor1 = double.Parse(Console.ReadLine());//aqui le estoy asignando el primer valor a mi primer variable encapsulada
            Console.WriteLine("----------------------------");
            Console.WriteLine("ingrese el segundo numero");
            mos.Valor2 = double.Parse(Console.ReadLine());//aqui igual pido el segundo valor en mi variabre encapsulada
            Menu();//aqui mando a llamar el menu para que ejecute todo lo que contiene 
        }
        public void Menu()
        {
            int opc;//creo la variable para que el usuario pueda elejir una opcion 
            Console.WriteLine("1-Suma");
            Console.WriteLine("2-Resta");
            Console.WriteLine("3-Multiplicacion");
            Console.WriteLine("4-Division");
            Console.WriteLine("ingrese la operacion que desea realizar");
            opc = Convert.ToInt32(Console.ReadLine());
            switch (opc)
            {
                case 1:
                    double res = mos.Valor1 + mos.Valor2;
                    Console.WriteLine("El resultado de la suma es : "+res);
                    break;
                case 2:
                    double res2 = mos.Valor1 - mos.Valor2;
                    Console.WriteLine("El resultado de la resta es : " + res2);
                    break;
                case 3:
                    double res3 = mos.Valor1 * mos.Valor2;
                    Console.WriteLine("El resultado de la multiplicacion es : " + res3);
                    break;
                case 4:
                    double res4 = mos.Valor1 / mos.Valor2;
                    /*creo una variable para poder almacenar el resultado de la suma de las variables 
                     encapsuladas*/
                    Console.WriteLine("El resultado de la division es : " + res4);
                    break;
                default:
                    Console.WriteLine("opcion no valiadad");
                    Console.WriteLine("regresando al menu");
                    Menu();
                    break;
            }
        }
    }
}
