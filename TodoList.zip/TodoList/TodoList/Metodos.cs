﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoList
{
  public class Metodos
    {
        public void Crear()
        {
            Tamañoarreglo();
            for (int i = 0; i < Listas.Length; i++)
            {

                Console.WriteLine((i+1)+"-ingrese a la persona que va asignar la tarea ");
                t.Nombre = Console.ReadLine();
                Console.WriteLine((i + 1) +"-ingrese la actividad");
                t.Actividad = Console.ReadLine();
                Console.WriteLine((i + 1) +"-ingrese la hora");
                t.Hora = Console.ReadLine();
                Console.WriteLine((i + 1) +"-ingrese fecha");
                t.Fecha = Console.ReadLine();
                Estatus();
                Listas[i] = t;
                Console.Clear();
            }
            Principal pr = new Principal();
            pr.Menu();
        }
        Tareas[] Listas;
        /*en este metodo le pido al 
         usuario que ingrese el tamaño de
         su arreglo */
        public void Tamañoarreglo()
        {
            Console.WriteLine("eliga el tamaño de su arreglo ");
            int n = Convert.ToInt32(Console.ReadLine());
            Listas = new Tareas[n];
        }
        /*en este otro metodo lo que voy a hacer 
         es que cada que el usuario quiera 
         agregar una nueva tarea  la pueda 
         agregar sin ningun problema */
        Tareas t = new Tareas(); 
        public void Estatus()
        {
            Console.WriteLine("Estatus");
            Console.WriteLine("1- sin iniciar");
            Console.WriteLine("2- en proceso");
            Console.WriteLine("3- finalizado");
            switch (Console.ReadLine())
            {
                case "1":
                    t.Status = "sin iniciar";
                    break;
                case "2":
                    t.Status = "en proceso";
                    break;
                case "3":
                    t.Status = "finalizado";
                    break;
                default:
                    Console.WriteLine("opcion no validad intente otra vez");
                    Estatus();
                    break;
            }
        }
        /*en este metodo se van a imprimir 
         las tareas que ya estan existentes*/
        public void MostrarTareas(Tareas[]tarea)
        {
            Principal pr = new Principal();
            Console.WriteLine("Tareas:");
            for (int i=0;i<tarea.Length;i++)
            {
                Console.WriteLine("Nombre de la tarea: "+ tarea[i].Actividad);
            }
            Console.ReadKey();
            Console.Clear();
            pr.Bienvenida();

        }
        public void Detalles(Tareas[] x)
        {
            Principal pr = new Principal();
            Console.WriteLine("ingrese el nombre");
            string nombre = Console.ReadLine();
            for (int i=0;i<x.Length;i++)
            {
                if (x[i].Nombre == nombre)
                {
                    Console.WriteLine("Nombre "+ x[i].Nombre);
                    Console.WriteLine("Actividad "+x[i].Actividad);
                    Console.WriteLine("Fecha "+x[i].Fecha );
                    Console.WriteLine("Hora "+ x[i].Hora);
                    Console.WriteLine("Estatus "+x[i].Status );
                }
            }
            Console.ReadKey();
            Console.Clear();
            pr.Bienvenida();
        }
        public void MostrarEstatus(Tareas[]xx)
        {
            Principal p = new Principal();
            Console.WriteLine("Estatus");
            for (int i = 0; i < xx.Length; i++)
            {
                Console.WriteLine("Nombre de la Actividad "+ xx[i].Actividad);
                Console.WriteLine("Estatus "+xx[i].Status );
            }
            Console.ReadKey();
            Console.Clear();
            p.Bienvenida();
        }
        public void CambiarEstatus(Tareas[]c)
        {
            Console.WriteLine("Ingrese el Nombre De la Actividad");
            string tarea = Console.ReadLine();
            for (int i=0;i<c.Length;i++)
            {
                if (tarea == c[i].Actividad)
                {
                    Console.WriteLine("Nombre "+c[i].Nombre);
                    Console.WriteLine("Actividad "+c[i].Actividad);
                    Console.WriteLine("Estatus "+c[i].Status);
                    Console.WriteLine("Cambio de Estatus");
                    Console.WriteLine("1-Sin Iniciar");
                    Console.WriteLine("2-En Proceso");
                    Console.WriteLine("3-Finalizada");
                    Console.WriteLine("eliga El Estatus");
                    switch (Console.ReadLine())
                    {
                        case "1":
                            c[i].Status = "sin iniciar";
                            break;
                        case "2":
                            c[i].Status = "En Proceso";
                            break;
                        case "3":
                            c[i].Status = "Finalizado";
                            break;
                        default:
                            Console.WriteLine("opcion no validad");
                            CambiarEstatus(c);
                            break;
                    }
                    Console.WriteLine("Estatus Actualizado "+c[i].Status);
                }
                Principal p = new Principal();
                Console.ReadKey();
                Console.Clear();
                p.Bienvenida();
            }
            
        }
        public void Opciones()
        {
            Console.WriteLine("Eliga Una Opcion");
            var opc = Console.ReadLine();
            switch (opc)
            {
                case "1":
                    Crear();
                    break;
                case "2":
                    MostrarTareas(Listas);
                    break;
                case "3":
                    Detalles(Listas);
                    break;
                case "4":
                    MostrarEstatus(Listas);
                    break;
                case "5":
                    CambiarEstatus(Listas);
                    break;
                default:
                    Console.WriteLine("opcion no validad");
                    Opciones();
                    break;
            }
        }
    }
}
