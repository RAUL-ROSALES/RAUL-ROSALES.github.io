﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoList
{
   public class Principal
    {
        public void Bienvenida()
        {
            Console.WriteLine("Bienvenido A Lista de Tareas");
            Menu();
            
            
        }
        public void Menu()
        {
            Console.WriteLine("1-Crear una nueva Tarea");
            Console.WriteLine("2-Mostrar Tareas");
            Console.WriteLine("3-Detalles");
            Console.WriteLine("4-Mostrar Estatus");
            Console.WriteLine("5-Cambiar Estatus");
            Metodos m = new Metodos();
            m.Opciones();
            
        }       
    }
}
