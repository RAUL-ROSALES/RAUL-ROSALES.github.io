﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoList
{
  public class Tareas
    {
        public string Nombre { get; set; }
        public string Actividad { get; set; }
        public string Fecha { get; set; }
        public string Hora { get; set; }
        public string Status { get; set; }
    }
}
